#include "scores.h"

int main()
{
int i = 0;
while(i<10){
	int userLevel;
	cout << "Enter a Game Level between 3-7 TO WRITE TO!" << endl;
	cin >> userLevel;

	cout << "Current Scores:";
	scoresList list(userLevel);
	list.readFile();
	cout << endl;


	cout << "Enter a name followed by a score to add" << endl;
	string nm;
	int sc;
	cin >> nm >> sc;

	highScore test_score(nm, sc);
	list.addHighScore(test_score);
	list.writeToFile();
/*
	cout << "Enter a Game Level between 3-7 TO READ the scores from that list." << endl;
	cin >> userLevel;
	scoresList list2(userLevel);
	list2.readFile();
	*/
	i++;
}
	

	return 0;
}